exports.textMenu = (sender, nama, namabot) => {
  return `*Halo @${sender.split("@")[0]}* 👋

[ *RANDOM-MENU* ]
• !sticker
• !info

© ${namabot} | by *${nama}* | 🇮🇩`
}